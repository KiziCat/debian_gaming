#!/usr/bin/env bash
# shellcheck shell=bash
# Shared helpers for the installer (host side) and the chroot setup.

C_RED=$'\e[31m'; C_GRN=$'\e[32m'; C_YEL=$'\e[33m'; C_BLU=$'\e[34m'; C_RST=$'\e[0m'

log()  { echo "${C_GRN}[+]${C_RST} $*"; }
info() { echo "${C_BLU}[i]${C_RST} $*"; }
warn() { echo "${C_YEL}[!]${C_RST} $*" >&2; }
die()  { echo "${C_RED}[x]${C_RST} $*" >&2; exit 1; }

# ask "Prompt" [default]  -> prints the answer (prompt goes to stderr)
ask() {
    local prompt=$1 default=${2:-} reply
    read -r -p "$prompt${default:+ [$default]}: " reply </dev/tty
    echo "${reply:-$default}"
}

# ask_yn "Prompt" y|n  -> returns 0 for yes
ask_yn() {
    local prompt=$1 default=${2:-n} reply hint
    [[ $default == y ]] && hint="Y/n" || hint="y/N"
    read -r -p "$prompt [$hint]: " reply </dev/tty
    reply=${reply:-$default}
    [[ $reply =~ ^[Yy] ]]
}

# prompt_var VAR "Prompt" [default]  -> skipped when VAR is already set (non-interactive runs)
prompt_var() {
    local var=$1
    [[ -n ${!var:-} ]] && return 0
    local value
    value=$(ask "$2" "${3:-}")
    printf -v "$var" '%s' "$value"
}

# --- apt helpers (used inside the target system) ------------------------------------------

has_candidate() {
    local c
    c=$(apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/ {print $2}')
    [[ -n $c && $c != "(none)" ]]
}

# install_core pkg...       strict: any failure aborts
install_core() {
    apt-get install -y "$@"
}

# install_available pkg...  tolerant: skips packages that don't exist in the configured suites
install_available() {
    local ok=() miss=() p
    for p in "$@"; do
        if has_candidate "$p"; then ok+=("$p"); else miss+=("$p"); fi
    done
    ((${#miss[@]})) && warn "not available, skipped: ${miss[*]}"
    ((${#ok[@]})) || return 0
    apt-get install -y "${ok[@]}" || { warn "some of these failed to install: ${ok[*]}"; return 1; }
}
