#!/usr/bin/env bash
# shellcheck shell=bash
# Shared helpers for the installer (host side) and the chroot setup.

C_RED=$'\e[31m'; C_GRN=$'\e[32m'; C_YEL=$'\e[33m'; C_BLU=$'\e[34m'; C_RST=$'\e[0m'

log()  { echo "${C_GRN}[+]${C_RST} $*"; }
info() { echo "${C_BLU}[i]${C_RST} $*"; }
warn() { echo "${C_YEL}[!]${C_RST} $*" >&2; }
die()  { echo "${C_RED}[x]${C_RST} $*" >&2; exit 1; }

# ask "Prompt" [default]  -> prints the answer (prompt goes to stderr)
ask() {
    local prompt=$1 default=${2:-} reply
    read -r -p "$prompt${default:+ [$default]}: " reply </dev/tty || { echo "No input available (no terminal?)" >&2; return 1; }
    echo "${reply:-$default}"
}

# ask_yn "Prompt" y|n  -> returns 0 for yes
ask_yn() {
    local prompt=$1 default=${2:-n} reply hint
    [[ $default == y ]] && hint="Y/n" || hint="y/N"
    read -r -p "$prompt [$hint]: " reply </dev/tty || return 1
    reply=${reply:-$default}
    [[ $reply =~ ^[Yy] ]]
}

# prompt_var VAR "Prompt" [default]  -> skipped when VAR is already set (non-interactive runs)
prompt_var() {
    local var=$1
    [[ -n ${!var:-} ]] && return 0
    local value
    value=$(ask "$2" "${3:-}")
    printf -v "$var" '%s' "$value"
}

# pick_disk [excluded-disk]  -> sets DISK from a numbered list
pick_disk() {
    local exclude=${1:-} i=0 line choice
    local -a names=()
    echo; info "Available disks:"
    while IFS= read -r line; do
        local NAME="" SIZE="" TYPE="" TRAN="" MODEL=""
        eval "$line"                       # lsblk -P output: KEY="value" pairs
        [[ $TYPE == disk ]] || continue
        [[ $NAME == "$exclude" ]] && continue
        i=$((i + 1)); names+=("$NAME")
        printf '  %d) %-14s %8s  %s%s\n' "$i" "$NAME" "$SIZE" "${MODEL:-unknown model}" "${TRAN:+  [$TRAN]}"
    done < <(lsblk -dpn -P -o NAME,SIZE,TYPE,TRAN,MODEL 2>/dev/null)
    ((i)) || die "No installable disks found."
    echo
    while :; do
        choice=$(ask "Install to which disk? (enter the number)")
        if [[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= i)); then
            DISK=${names[choice - 1]}
            return 0
        fi
        warn "Please enter a number between 1 and $i."
    done
}

_tz_list() {
    local out
    out=$(timedatectl list-timezones 2>/dev/null) || out=""
    [[ -n $out ]] || out=$(awk '$1=="Z"{print $2} $1=="L"{print $3}' /usr/share/zoneinfo/tzdata.zi 2>/dev/null | sort -u) || out=""
    printf '%s\n' "$out"
}

# pick_timezone [default]  -> sets TIMEZONE. Accepts "Europe/Warsaw", "europe/warsaw", "warsaw", "new york", "berl"...
pick_timezone() {
    local default=${1:-UTC} all input key hit choice z i
    local -a hits
    all=$(_tz_list)
    if [[ -z $all ]]; then TIMEZONE=$default; warn "No timezone database found, using $default"; return 0; fi
    while :; do
        input=$(ask "Timezone - type a city or Region/City (e.g. Warsaw, europe/berlin, new york)" "$default")
        key=${input,,}; key=${key// /_}
        hit=$(grep -ixF -- "$key" <<<"$all" | head -n1) || true          # exact "Region/City"
        if [[ -z $hit ]]; then
            mapfile -t hits < <(awk -F/ -v k="$key" 'tolower($NF)==k' <<<"$all")   # exact city name
            ((${#hits[@]})) || mapfile -t hits < <(grep -iF -- "$key" <<<"$all" | head -n 20)  # partial match
            if ((${#hits[@]} == 0)); then
                warn "No timezone matches '$input'. Try just the city name."; continue
            elif ((${#hits[@]} == 1)); then
                hit=${hits[0]}
            else
                i=0; for z in "${hits[@]}"; do i=$((i + 1)); printf '  %2d) %s\n' "$i" "$z"; done
                choice=$(ask "Pick a number (just Enter to search again)")
                [[ $choice =~ ^[0-9]+$ ]] && ((choice >= 1 && choice <= ${#hits[@]})) || continue
                hit=${hits[choice - 1]}
            fi
        fi
        TIMEZONE=$hit; info "Timezone set to $TIMEZONE"; return 0
    done
}

# --- apt helpers (used inside the target system) ------------------------------------------

has_candidate() {
    local c
    c=$(apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/ {print $2}')
    [[ -n $c && $c != "(none)" ]]
}

# install_core pkg...       strict: any failure aborts
install_core() {
    apt-get install -y "$@"
}

# install_available pkg...  tolerant: skips packages that don't exist in the configured suites
install_available() {
    local ok=() miss=() p
    for p in "$@"; do
        if has_candidate "$p"; then ok+=("$p"); else miss+=("$p"); fi
    done
    ((${#miss[@]})) && warn "not available, skipped: ${miss[*]}"
    ((${#ok[@]})) || return 0
    apt-get install -y "${ok[@]}" || { warn "some of these failed to install: ${ok[*]}"; return 1; }
}
